package com.example.quiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.ArrayList;

public class Student_detail extends AppCompatActivity  {
    private Intent In;
    private ArrayList<Student> Students;
    private TextView Id, N1,N2,N3,NF;
    private double n1,n2,n3,nf =0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data);

        In = getIntent();
        Students = Data.Get();

        Id = (TextView)findViewById(R.id.id1);
        N1 = (TextView)findViewById(R.id.note1);
        N2 = (TextView)findViewById(R.id.note2);
        N3 = (TextView)findViewById(R.id.note3);
        NF = (TextView)findViewById(R.id.notef);


        loadData(Students.get(In.getIntExtra("position", 0)));
    }

    private void loadData(Student student){

        Id.setText(String.valueOf(student.getId()));
        N1.setText(String.valueOf(student.getNota1()));
        N2.setText(String.valueOf(student.getNota2()));
        N3.setText(String.valueOf(student.getNota3()));
        NF.setText(String.valueOf(student.getFn()));
    }
}
