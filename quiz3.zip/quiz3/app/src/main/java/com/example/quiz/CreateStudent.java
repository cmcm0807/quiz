package com.example.quiz;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class CreateStudent extends AppCompatActivity {
    private EditText Name, LastName, Id,N1,N2,N3;
    private android.content.res.Resources Resources;
    private ArrayList<Student> Students;

    @Override
    protected void onCreate(Bundle saveInstanceStated){
        super.onCreate(saveInstanceStated);
        setContentView(R.layout.create_student);

        Name=(EditText)findViewById(R.id.txtName);
        LastName=(EditText)findViewById(R.id.txtLastname);
        Id=(EditText)findViewById(R.id.txtId);
        N1=(EditText)findViewById(R.id.txtN1);
        N2=(EditText)findViewById(R.id.txtN2);
        N3=(EditText)findViewById(R.id.txtN3);

        Resources =this.getResources();
        Students= Data.Get();

    }
    public void Saved (View view){
        String IDv, NameV, LastNameV, N1v, N2v, N3v,Fn;
        Double n1,n2,n3,Fnv = 0.0;
        IDv = Id.getText().toString();
        NameV= Name.getText().toString();
        LastNameV = LastName.getText().toString();
        N1v=N1.getText().toString();
        N2v=N2.getText().toString();
        N3v=N3.getText().toString();
        n1=Double.parseDouble(N1v);
        n2=Double.parseDouble(N2v);
        n3=Double.parseDouble(N3v);
        Fnv+=((n1+n2+n3)/3);

        Student c = new Student(NameV, LastNameV, Integer.parseInt(IDv),Double.parseDouble(N1v),Double.parseDouble(N2v),Double.parseDouble(N3v),Fnv);
        c.SaveStudent();
        Toast.makeText(this, R.string.done, Toast.LENGTH_LONG).show();
    }




}
